"""Independent anniversary calendar check; does not import workbook generators."""
import json
from pathlib import Path
R=Path(__file__).resolve().parent
wb=json.loads((R/'workbook_results.json').read_text())
controls=json.loads((R/'control_results.json').read_text())
cases=[
 dict(p=4,e=2,n=0,delay=2,ret=.85,eff=0,growth=[4,6,8],nodes=[0,1,1],fixed=[130,170,210]),
 dict(p=8,e=4,n=1,delay=0,ret=.9,eff=.05,growth=[6,9,12],nodes=[1,2,2],fixed=[175,240,320]),
 dict(p=12,e=6,n=2,delay=0,ret=.93,eff=.08,growth=[9,13,18],nodes=[2,3,4],fixed=[230,330,460])]
# Raw unit assumptions: price, support, project duration, engineering, direct cost, annual support cost.
units={'P':(8,0,2,3,3.7,0),'E':(55,12,4,18,25.4,3.6),'N':(120,24,7,42,59.6,7.2)}
starts={'P':[3,4,5,6,7,8,9,10,10,11,11,12],'E':[6,7,8,9,9,10],'N':[6,9]}
def expected(c,price=1,cost=1):
    result=[dict(support=0,supportcost=0,renew=0,arr=0,tailfee=0,tailcost=0,tailbooks=0,tailem=0) for _ in range(4)]
    cohorts=[]
    for kind in units:
        fee,ann,duration,em,direct,supportcost=units[kind]
        for sm in starts[kind][:c[kind.lower()]]:
            sm+=c['delay'];end=sm+duration-1
            if 13<=end<=24:
                result[1]['tailfee']+=fee*price
                result[1]['tailcost']+=direct*cost
            if 13<=sm<=24:
                result[1]['tailbooks']+=(fee+ann)*price
                result[1]['tailcost']+=(fee+ann)*price*.05
            result[1]['tailem']+=sum(em/duration for m in range(13,25) if sm<=m<=end)
            if ann:cohorts.append((sm,end+1,ann*price,supportcost*cost))
    for y in range(2,5):
        for kind,count in [('E',c['growth'][y-2]),('N',c['nodes'][y-2])]:
            _,ann,_,_,_,cs=units[kind]
            cohorts.append(((y-1)*12+1,(y-1)*12+7,count*ann*price,count*cs*cost))
    for sign,start,ann,cs in cohorts:
        for m in range(1,49):
            y=(m-1)//12
            if m>=start:
                age=(m-start)//12
                weight=c['ret']**age
                result[y]['support']+=ann*weight/12
                result[y]['supportcost']+=cs*weight/12
                if age>0 and (m-start)%12==0:result[y]['renew']+=ann*weight
            if m%12==0 and sign<=m:
                # Signed but not yet activated is included in contracted ARR.
                age=max(0,(m-start)//12)
                result[y]['arr']+=ann*c['ret']**age
    for y in range(2,5):
        z=result[y-1];E=c['growth'][y-2];N=c['nodes'][y-2];P=E*2
        fee=(55*E+120*N+8*P)*price;support=(12*E+24*N)*price
        projectcost=(25.4*E+59.6*N+3.7*P)*cost*(1-c['eff'])**(y-1)
        z['revenue']=fee+z['support']+z['tailfee']
        z['bookings']=fee+support+z['renew']+z['tailbooks']
        z['cost']=projectcost+z['supportcost']+(fee+support+z['renew'])*.05+z['tailcost']
        z['op']=z['revenue']-z['cost']-c['fixed'][y-2]
        z['em']=(18*E+42*N+3*P)*(1-c['eff'])**(y-1)+z['tailem']
    return result
mapping={'全部支持收入（按到期月）':'support','全部支持直接成本':'supportcost','期末合同支持ARR':'arr','收入合计':'revenue','预计签约':'bookings','成本合计':'cost','经营贡献':'op','工程人月需求':'em'}
checks=[]
def compare(label,out,c,price=1,cost=1):
    a={r[0]:r[1:] for r in out['annual'][1:]}
    ex=expected(c,price,cost)
    for y in range(2,5):
        for name,key in mapping.items():
            diff=abs(a[name][y-1]-ex[y-1][key])
            assert diff<1e-7,(label,y,name,a[name][y-1],ex[y-1][key])
            checks.append(dict(test=label,year=y,metric=name,expected=ex[y-1][key],actual=a[name][y-1],difference=diff))
for i,c in enumerate(cases,1):compare(f'情景{i}',wb[str(i)],c)
for k,kw in [('报价调整系数',{'price':.85}),('成本调整系数',{'cost':1.2}),('续费保留率',{}),('签约延迟月数',{})]:
    c=cases[1].copy()
    if k=='续费保留率':c['ret']=0
    if k=='签约延迟月数':c['delay']=3
    compare(k,controls[k],c,**kw)
assert dict(controls['生产项目数']['checks'])['启用数量超模板']==1
for v in wb.values():
    for name,num in v['checks']:
        assert num<=1e-7 if name in ['总回款不超过开票','全部收入与合同差'] else abs(num)<1e-7,(name,num)
target=R/'复盘核验.json'
target.write_text(json.dumps({'独立周年队列核验':checks,'边界':'生产数量7超6槽位已触发错误提示；零保留率不提前损失首期合同收入','未实证':'成交概率、报价、实际工程成本与税务结构仍为经营假设'},ensure_ascii=False,indent=2))
print('independent annual/control checks',len(checks),'PASS')
