from pathlib import Path
import json, math
ROOT=Path(__file__).resolve().parent
OUT=ROOT
OUT.mkdir(parents=True,exist_ok=True)
SOURCES=json.loads((ROOT/'来源与口径.json').read_text())['sources']
CASES=[{'name':'谨慎进入','p':4,'e':2,'n':0,'delay':2,'collect':2,'staff':0.82,'growth':[4,6,8],'nodes':[0,1,1]},
       {'name':'资源到位目标','p':8,'e':4,'n':1,'delay':0,'collect':1,'staff':1,'growth':[6,9,12],'nodes':[1,2,2]},
       {'name':'突破目标','p':12,'e':6,'n':2,'delay':0,'collect':1,'staff':1.28,'growth':[9,13,18],'nodes':[2,3,4]}]
PRICES={'P':{'name':'收费验证','fee':8,'annual':0,'months':2,'em':3,'local':.5,'cloud':.3,'audit':.3,'travel':.2,'support':0},
        'E':{'name':'企业生产平台','fee':55,'annual':12,'months':4,'em':18,'local':5,'cloud':2,'audit':2,'travel':2,'support':.3},
        'N':{'name':'产业连接平台','fee':120,'annual':24,'months':7,'em':42,'local':12,'cloud':6,'audit':5,'travel':3,'support':.6}}
ROLES=[['国家经理','USD',20000,1,12,1,1],['UAE商务','AED',27500,2,12,1,1.18],['沙特商务','SAR',30000,3,12,1,1.20],['方案架构师','AED',42500,2,12,1,1.18],['交付经理','AED',35000,4,12,1,1.18],['运营行政','AED',15000,1,12,.5,1.18]]
OPEX=[['两国设立与初始法律',10,1,2],['会计法律保险持续费用',8,1,12],['办公与工具',7.2,1,12],['客户差旅与会议',9.6,1,12],['本地化与售前产品适配',12,1,6],['培训与招聘',4,2,4]]
def simulate(case,fee_factor=1,extra_delay=0,collect_extra=0,cost_factor=1,drop_node=False):
    c=dict(case); data=[]
    for k,starts in [('P',[3,4,5,6,7,8,9,10,10,11,11,12]),('E',[6,7,8,9,9,10]),('N',[6,9])]:
        for i,s in enumerate(starts[:c[k.lower()]]):
            if k=='N' and drop_node:continue
            p=PRICES[k]; sign=s+c['delay']+extra_delay; end=sign+p['months']-1
            data.append(dict(id=f'{k}{i+1:02}',kind=k,sign=sign,end=end,p=p))
    months=[];cum=0;billcum=0;revcum=0;cashcum=0;cashcostcum=0;costcum=0;bookcum=0
    for m in range(1,25):
        bookings=revenue=bills=cash=dcash=cogs=em=arr=0
        for d in data:
            p=d['p'];s=d['sign'];e=d['end'];fee=p['fee']*fee_factor;ann=p['annual']*fee_factor
            direct=(p['em']*.8+p['local']+p['cloud']+p['audit']+p['travel'])*cost_factor
            upfront=lambda t: (fee*.3 if t==s else 0)+(fee*.4 if t==s+(p['months']//2) else 0)+(fee*.3 if t==e else 0)+(ann if t==e+1 else 0)
            if m==s:bookings+=fee+ann
            if m==e:revenue+=fee;cogs+=direct
            if e+1<=m<=e+12:revenue+=ann/12;cogs+=p['support']*cost_factor;dcash+=p['support']*cost_factor;arr+=ann
            bills+=upfront(m);cc=upfront(m-c['collect']-collect_extra);cash+=cc
            # Sales commissions expense at contract inception, paid only after customer cash; no capitalisation assumed.
            if m==s:cogs+=(fee+ann)*.05
            dcash+=cc*.05
            if s<=m<=e:dcash+=direct/p['months'];em+=p['em']/p['months']
        staff=0
        for name,fx,pay,start,end,fte,load in ROLES:
            if start<=m<=12:
                rate={'USD':1,'AED':3.6725,'SAR':3.75}[fx]
                staff+=pay/rate/10000*fte*load*(1 if fx=='USD' else 1.05)*c['staff']
        non=sum(total/(end-start+1)*c['staff'] for _,total,start,end in OPEX if start<=m<=end)
        fixed=staff+non
        # Months13–24 only runoff of Y1 contracts, no new sales or permanent overhead.
        out=dcash+fixed;net=cash-out;cum+=net;billcum+=bills;revcum+=revenue;cashcum+=cash;cashcostcum+=dcash;costcum+=cogs;bookcum+=bookings
        months.append(dict(month=m,bookings=bookings,revenue=revenue,bills=bills,cash=cash,cogs=cogs,dcash=dcash,staff=staff,non=non,fixed=fixed,out=out,net=net,cum=cum,em=em,arr=arr,AR=billcum-cashcum,contract_net=billcum-revcum,commission_AP=(bookcum-cashcum)*.05,work_in_progress=cashcostcum-costcum+(bookcum-cashcum)*.05))
    y=months[:12];res={k:sum(x[k] for x in y) for k in ['bookings','revenue','cash','cogs','dcash','staff','non','fixed','out','net','em']}
    res['gross']=res['revenue']-res['cogs'];res['op']=res['gross']-res['fixed'];res['margin']=res['gross']/res['revenue'] if res['revenue'] else 0
    res['peak_need']=max(0,-min(x['cum'] for x in y));res['reserve']=3*sum(x['fixed'] for x in y[-3:])/3
    res['funding']=res['peak_need']+res['reserve'];res['peak_engineers']=max(x['em'] for x in y)/.75
    res['active_arr']=y[-1]['arr'];res['contracted_arr']=sum(d['p']['annual']*fee_factor for d in data if d['sign']<=12)
    res['production']=sum(d['kind']!='P' and d['end']<=12 for d in data)
    return dict(name=c['name'],summary=res,months=months,contracts=[{k:v for k,v in d.items() if k!='p'} for d in data])
RESULTS=[simulate(c) for c in CASES]
stress={name:simulate(CASES[1],**kw)['summary'] for name,kw in [('基准',{}),('签约整体延后3个月',{'extra_delay':3}),('回款再延后2个月',{'collect_extra':2}),('未赢产业平台',{'drop_node':True}),('报价下降15%',{'fee_factor':.85}),('直接成本上升20%',{'cost_factor':1.2}),('延迟及成本双压',{'extra_delay':3,'collect_extra':2,'cost_factor':1.2})]}
(OUT/'独立计算结果.json').write_text(json.dumps({'cases':RESULTS,'stress':stress},ensure_ascii=False,indent=2))
print(json.dumps({'cases':[{ 'name':r['name'],**r['summary']} for r in RESULTS], 'stress':stress},ensure_ascii=False,indent=2))
